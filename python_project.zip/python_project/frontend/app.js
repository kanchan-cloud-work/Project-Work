document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const errorMessage = document.getElementById('errorMessage');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultsContainer = document.getElementById('resultsContainer');
    const uploadSection = document.getElementById('uploadSection');
    
    // Metrics Elements
    const predictedExpenseEl = document.getElementById('predictedExpense');
    const predictedSavingsEl = document.getElementById('predictedSavings');
    const avgMonthlyExpenseEl = document.getElementById('avgMonthlyExpense');
    
    // Category Breakdown Container
    const categoryBreakdown = document.getElementById('categoryBreakdown');
    
    // Canvas Element
    const financialChartCanvas = document.getElementById('financialChart');
    const resetBtn = document.getElementById('resetBtn');
    
    // Global variable to keep the last prediction data for resizing
    let currentChartData = null;

    // 1. Drag & Drop Event Listeners
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('drag-over');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('drag-over');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('drag-over');
        
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            handleFileUpload(e.dataTransfer.files[0]);
        }
    });

    dropZone.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            handleFileUpload(fileInput.files[0]);
        }
    });

    resetBtn.addEventListener('click', () => {
        resetUI();
    });

    // Handle window resizing for responsive Canvas redrawing
    window.addEventListener('resize', () => {
        if (currentChartData && !resultsContainer.classList.contains('hidden')) {
            drawChart(financialChartCanvas, currentChartData);
        }
    });

    // 2. Main File Upload Processor
    function handleFileUpload(file) {
        // Clear previous error message
        hideError();

        // Safe extension validation
        const fileExtension = file.name.split('.').pop().toLowerCase();
        if (fileExtension !== 'csv') {
            showError('Invalid file format. Please select a .csv file.');
            return;
        }

        // Safe size validation (5MB limit)
        const maxSize = 5 * 1024 * 1024;
        if (file.size > maxSize) {
            showError('File is too large. Maximum size is 5MB.');
            return;
        }

        // Show loading state, hide upload section
        uploadSection.classList.add('hidden');
        loadingSpinner.classList.remove('hidden');

        // Create FormData and request
        const formData = new FormData();
        formData.append('file', file);

        // Fetch API prediction endpoint
        fetch('/api/predict', {
            method: 'POST',
            body: formData,
            mode: 'cors'
        })
        .then(async response => {
            if (!response.ok) {
                let errMsg = 'Server returned an error. Please verify the CSV format.';
                try {
                    const errData = await response.json();
                    if (errData && errData.error) {
                        errMsg = errData.error;
                    }
                } catch (e) {
                    // Ignore JSON parsing errors and use default message
                }
                throw new Error(errMsg);
            }
            return response.json();
        })
        .then(data => {
            // Success: Update UI metrics, breakdown progress bars, and draw chart
            renderResults(data);
        })
        .catch(error => {
            console.error('API Error:', error);
            showError(error.message || 'An unexpected error occurred while processing the file.');
            
            // Revert state
            loadingSpinner.classList.add('hidden');
            uploadSection.classList.remove('hidden');
        });
    }

    // 3. UI Renderer
    function renderResults(data) {
        // Format currencies nicely
        predictedExpenseEl.textContent = formatCurrency(data.predicted_total_expense);
        avgMonthlyExpenseEl.textContent = formatCurrency(data.avg_monthly_expense);
        
        const savings = data.predicted_savings;
        predictedSavingsEl.textContent = formatCurrency(savings);

        // Color coding for savings (red if negative, green if positive)
        if (savings < 0) {
            predictedSavingsEl.style.color = '#ef4444'; // Red
        } else {
            predictedSavingsEl.style.color = '#10b981'; // Emerald Green
        }

        // Render Category Progress Bars safely (No innerHTML)
        renderCategoryBreakdown(data.category_averages);

        // Hide loader and show dashboard
        loadingSpinner.classList.add('hidden');
        resultsContainer.classList.remove('hidden');

        // Draw custom Canvas line chart
        currentChartData = data.chart_data;
        drawChart(financialChartCanvas, data.chart_data);
    }

    // 4. Render Budget Progress Bars (XSS-safe)
    function renderCategoryBreakdown(averages) {
        // Clear previous children
        categoryBreakdown.replaceChildren();

        const totalExpense = Object.values(averages).reduce((sum, val) => sum + val, 0);

        Object.entries(averages).forEach(([key, val]) => {
            const percentage = totalExpense > 0 ? (val / totalExpense) * 100 : 0;
            
            // Format category name (e.g. rent_utilities -> Rent & Utilities)
            const displayName = key
                .split('_')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' & ');

            // Create container
            const itemDiv = document.createElement('div');
            itemDiv.className = 'breakdown-item';

            // Create label row
            const labelRow = document.createElement('div');
            labelRow.className = 'breakdown-label-row';

            const nameSpan = document.createElement('span');
            nameSpan.textContent = displayName;

            const valSpan = document.createElement('span');
            valSpan.className = 'breakdown-value';
            valSpan.textContent = `${formatCurrency(val)} (${percentage.toFixed(0)}%)`;

            labelRow.appendChild(nameSpan);
            labelRow.appendChild(valSpan);

            // Create bar elements
            const barBg = document.createElement('div');
            barBg.className = 'breakdown-bar-bg';

            const barFill = document.createElement('div');
            barFill.className = 'breakdown-bar-fill';
            // Start at 0% and animate width in the next browser draw frame
            barFill.style.width = '0%';

            barBg.appendChild(barFill);
            itemDiv.appendChild(labelRow);
            itemDiv.appendChild(barBg);

            categoryBreakdown.appendChild(itemDiv);

            // Trigger CSS transition animation
            requestAnimationFrame(() => {
                barFill.style.width = `${percentage}%`;
            });
        });
    }

    // 5. Reset UI State
    function resetUI() {
        currentChartData = null;
        fileInput.value = '';
        hideError();
        resultsContainer.classList.add('hidden');
        uploadSection.classList.remove('hidden');
    }

    // 6. Safe Element Utilities
    function showError(message) {
        errorMessage.querySelector('.error-text').textContent = message;
        errorMessage.classList.remove('hidden');
    }

    function hideError() {
        errorMessage.classList.add('hidden');
    }

    function formatCurrency(val) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 0 // Optional: round to whole rupees for cleaner display
        }).format(val);
    }

    // 7. Custom Dual-Line Canvas Chart Engine
    function drawChart(canvas, data) {
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Device Pixel Ratio scaling for high definition screens
        const dpr = window.devicePixelRatio || 1;
        const rect = canvas.getBoundingClientRect();
        
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        ctx.scale(dpr, dpr);

        const width = rect.width;
        const height = rect.height;

        // Set dimensions padding
        const padding = { top: 40, right: 35, bottom: 40, left: 55 };

        // Pull coordinates
        const monthIndexes = data.map(d => d.month_index);
        const incomes = data.map(d => d.income);
        const expenses = data.map(d => d.total_expenses);

        const minX = Math.min(...monthIndexes);
        const maxX = Math.max(...monthIndexes);

        // Standardize Y scale using max of income or expenses
        const maxVal = Math.max(...incomes, ...expenses);
        const minY = 0;
        const maxY = Math.ceil(maxVal * 1.15 / 500) * 500; // Round up to nearest 500 for clean ticks

        // X/Y conversion ratios
        const getX = (x) => padding.left + ((x - minX) / (maxX - minX || 1)) * (width - padding.left - padding.right);
        const getY = (y) => height - padding.bottom - ((y - minY) / (maxY - minY || 1)) * (height - padding.top - padding.bottom);

        // Draw horizontal grid lines and Y-axis labels
        const yTicks = 5;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;

        for (let i = 0; i <= yTicks; i++) {
            const yVal = minY + (i * (maxY - minY)) / yTicks;
            const yPos = getY(yVal);

            ctx.beginPath();
            ctx.moveTo(padding.left, yPos);
            ctx.lineTo(width - padding.right, yPos);
            ctx.stroke();

            // Y labels text
            ctx.fillStyle = '#9ca3af';
            ctx.font = '11px Outfit';
            ctx.textAlign = 'right';
            ctx.textBaseline = 'middle';
            ctx.fillText(formatCurrency(yVal), padding.left - 12, yPos);
        }

        // Draw vertical grid lines and X-axis labels with step filtering to prevent overcrowding
        let xStep = 1;
        if (data.length > 80) xStep = 20;
        else if (data.length > 40) xStep = 10;
        else if (data.length > 20) xStep = 5;
        else if (data.length > 10) xStep = 2;

        data.forEach(d => {
            const isEndpoint = d.month_index === minX || d.month_index === maxX;
            const isStep = d.month_index % xStep === 0;
            const isTooClose = !isEndpoint && (maxX - d.month_index < xStep * 0.7);

            if (isEndpoint || (isStep && !isTooClose)) {
                const xPos = getX(d.month_index);

                ctx.beginPath();
                ctx.moveTo(xPos, padding.top);
                ctx.lineTo(xPos, height - padding.bottom);
                ctx.stroke();

                // X labels text (Month Name)
                ctx.fillStyle = '#9ca3af';
                ctx.font = '11px Outfit';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'top';
                
                // Show month name or index fallback
                const labelText = d.month_name || `Month ${d.month_index}`;
                ctx.fillText(labelText, xPos, height - padding.bottom + 10);
            }
        });

        // Split data into history and prediction
        const histData = data.filter(d => !d.is_prediction);
        const predPoint = data.find(d => d.is_prediction);

        // --- DRAW INCOME LINE (Historical only) ---
        if (histData.length > 0) {
            ctx.beginPath();
            ctx.strokeStyle = '#10b981'; // Emerald Green
            ctx.lineWidth = 3;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';

            ctx.moveTo(getX(histData[0].month_index), getY(histData[0].income));
            for (let i = 1; i < histData.length; i++) {
                ctx.lineTo(getX(histData[i].month_index), getY(histData[i].income));
            }
            ctx.stroke();
        }

        // --- DRAW EXPENSE LINE (Historical) ---
        if (histData.length > 0) {
            ctx.beginPath();
            ctx.strokeStyle = '#6366f1'; // Indigo
            ctx.lineWidth = 3;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';

            ctx.moveTo(getX(histData[0].month_index), getY(histData[0].total_expenses));
            for (let i = 1; i < histData.length; i++) {
                ctx.lineTo(getX(histData[i].month_index), getY(histData[i].total_expenses));
            }
            ctx.stroke();
        }

        // --- DRAW EXPENSE PREDICTION SEGMENT (Dashed Teal Line) ---
        if (predPoint && histData.length > 0) {
            const lastHist = histData[histData.length - 1];
            ctx.beginPath();
            ctx.strokeStyle = '#14b8a6'; // Teal
            ctx.lineWidth = 2.5;
            ctx.setLineDash([5, 5]);

            ctx.moveTo(getX(lastHist.month_index), getY(lastHist.total_expenses));
            ctx.lineTo(getX(predPoint.month_index), getY(predPoint.total_expenses));
            ctx.stroke();
            
            // Reset line dash pattern
            ctx.setLineDash([]);
        }

        // --- DRAW DATA POINTS ---
        data.forEach(d => {
            const xPos = getX(d.month_index);

            // Draw historical Income nodes (Green dots)
            if (!d.is_prediction) {
                const incomeY = getY(d.income);
                ctx.fillStyle = '#10b981';
                ctx.beginPath();
                ctx.arc(xPos, incomeY, 3.5, 0, Math.PI * 2);
                ctx.fill();

                // Draw historical Expense nodes (Indigo dots)
                const expenseY = getY(d.total_expenses);
                ctx.fillStyle = '#6366f1';
                ctx.beginPath();
                ctx.arc(xPos, expenseY, 3.5, 0, Math.PI * 2);
                ctx.fill();
            }

            // Draw prediction Expense node (Glowing Teal tag)
            if (d.is_prediction) {
                const expenseY = getY(d.total_expenses);

                // Glow effect configuration
                ctx.shadowBlur = 10;
                ctx.shadowColor = '#14b8a6';

                // Solid center
                ctx.fillStyle = '#14b8a6';
                ctx.beginPath();
                ctx.arc(xPos, expenseY, 6, 0, Math.PI * 2);
                ctx.fill();

                // Outer highlight ring
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(xPos, expenseY, 9, 0, Math.PI * 2);
                ctx.stroke();

                ctx.shadowBlur = 0; // Disable shadow for text

                // Label tag
                ctx.fillStyle = '#14b8a6';
                ctx.font = 'bold 11px Outfit';
                ctx.textAlign = 'center';
                ctx.fillText(formatCurrency(d.total_expenses), xPos, expenseY - 16);
            }
        });
    }
});
