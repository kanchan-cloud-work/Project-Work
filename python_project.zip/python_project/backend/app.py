import os
import uuid
import secrets
import logging
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from model import predict_cycle

# Setup logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask to serve frontend static files from ../frontend folder
app = Flask(__name__, static_folder='../frontend', static_url_path='')

# RESTRICTED CORS - Allow only local loopback hosts and file protocol (represented as "null")
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://127.0.0.1:5000", "http://localhost:5000", "null"]
    }
})

# Configure security parameters
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # Max 5MB upload size limit

# Generate secure ephemeral secret key
def get_secret_key():
    env_secret = os.environ.get('FLASK_SECRET_KEY')
    if env_secret:
        return env_secret
    logger.warning("Generating ephemeral secret key for session security.")
    return secrets.token_hex(32)

app.secret_key = get_secret_key()

# Configure upload directory outside web root
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_EXTENSIONS = {'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Serve main single-page application
@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

# API predict endpoint
@app.route('/api/predict', methods=['POST'])
def predict():
    # 1. Validate request content type and file existence
    if 'file' not in request.files:
        return jsonify({'error': 'No file part in the request.'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No file selected for upload.'}), 400

    # 2. Validate file extension (server-side check)
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file format. Only CSV files are allowed.'}), 400

    # 3. Inspect magic bytes / file content to verify it is text/CSV and not binary
    chunk = file.read(2048)
    file.seek(0)  # Reset pointer to start of file
    try:
        chunk_str = chunk.decode('utf-8')
        # Simple heuristic: Reject if it contains null bytes or has no csv characters
        if '\x00' in chunk_str or (',' not in chunk_str and '\n' not in chunk_str):
            return jsonify({'error': 'Invalid file format. Uploaded file is not a valid CSV text file.'}), 400
    except UnicodeDecodeError:
        return jsonify({'error': 'Invalid file format. Uploaded file contains binary characters.'}), 400

    # 4. Generate unique UUID filename to prevent path traversal attacks
    file_ext = file.filename.rsplit('.', 1)[1].lower()
    safe_filename = f"{uuid.uuid4().hex}.{file_ext}"
    filepath = os.path.join(UPLOAD_FOLDER, safe_filename)

    try:
        # Save file to upload directory
        file.save(filepath)
        
        # 5. Call regression model for prediction
        result = predict_cycle(filepath)
        return jsonify(result)
        
    except ValueError as ve:
        # Client-facing input validation errors
        logger.warning(f"Validation failure: {str(ve)}")
        return jsonify({'error': str(ve)}), 400
    except Exception as e:
        # Generic error message to user, detailed log in backend logs
        logger.error(f"Internal processing failure: {str(e)}", exc_info=True)
        return jsonify({'error': 'An internal server error occurred while processing the cycle data.'}), 500
    finally:
        # 6. Secure clean-up: remove the file from disk immediately
        if os.path.exists(filepath):
            try:
                os.remove(filepath)
            except Exception as e:
                logger.error(f"Failed to remove temp file {filepath}: {str(e)}")

# Apply security headers on all responses
@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    
    # Strict Content Security Policy (CSP)
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "style-src 'self' https://fonts.googleapis.com; "
        "font-src https://fonts.gstatic.com; "
        "connect-src 'self' http://127.0.0.1:5000 http://localhost:5000; "
        "img-src 'self' data:; "
        "frame-ancestors 'none';"
    )
    return response

if __name__ == '__main__':
    # Listen only on localhost/127.0.0.1 for local dev security
    app.run(host='127.0.0.1', port=5000, debug=True)
