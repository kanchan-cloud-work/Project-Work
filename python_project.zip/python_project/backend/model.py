import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

def predict_cycle(csv_path):
    """
    Reads a monthly expense CSV file, validates the inputs, runs Linear Regression
    on total expenses over time, and returns predictions and chart coordinates.
    """
    # Read the CSV file
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        raise ValueError(f"Failed to parse CSV file: {str(e)}")

    # Clean column names (strip whitespace and convert to lowercase)
    df.columns = [c.strip().lower() for c in df.columns]

    # Required columns validation
    required_cols = {'month_name', 'income', 'rent_utilities', 'food_groceries', 'entertainment_shopping', 'other'}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns in CSV: {', '.join(missing)}")

    # Drop rows that are completely empty or have NaNs in critical columns
    df = df.dropna(subset=['month_name', 'income', 'rent_utilities', 'food_groceries', 'entertainment_shopping', 'other'])

    if len(df) == 0:
        raise ValueError("CSV file contains no valid data rows.")

    # Parse and validate numeric columns
    numeric_cols = ['income', 'rent_utilities', 'food_groceries', 'entertainment_shopping', 'other']
    for col in numeric_cols:
        try:
            df[col] = pd.to_numeric(df[col], errors='raise')
        except Exception:
            raise ValueError(f"Invalid value in '{col}' column: must be numeric.")

    # Validate that values are positive
    if (df[numeric_cols] < 0).any().any():
        raise ValueError("Financial values (income, expenses) cannot be negative.")

    # Calculate total expenses for each month
    df['total_expenses'] = df['rent_utilities'] + df['food_groceries'] + df['entertainment_shopping'] + df['other']

    n_samples = len(df)
    if n_samples < 3:
        raise ValueError(f"At least 3 historical months are required for prediction (found {n_samples}).")

    # If month_index is present in the CSV, map it, otherwise generate it.
    if 'month_index' in df.columns:
        try:
            df['month_index'] = pd.to_numeric(df['month_index'], errors='raise')
        except Exception:
            df['month_index'] = range(1, n_samples + 1)
    else:
        df['month_index'] = range(1, n_samples + 1)

    # Sort chronologically by month index to enforce sequence
    df = df.sort_values('month_index').reset_index(drop=True)

    # Train Linear Regression model mapping month_index -> total_expenses
    X = df['month_index'].values.reshape(-1, 1)
    y = df['total_expenses'].values

    model = LinearRegression()
    model.fit(X, y)

    # Predict next month's total expenses
    next_month_index = int(df['month_index'].max() + 1)
    predicted_total_expense = float(model.predict(np.array([[next_month_index]]))[0])

    # Enforce reasonable lower bound on predicted expenses
    if predicted_total_expense < 0:
        predicted_total_expense = 0.0

    # Calculate average values
    avg_monthly_expense = float(df['total_expenses'].mean())
    
    # Calculate category averages
    category_averages = {
        'rent_utilities': round(float(df['rent_utilities'].mean()), 2),
        'food_groceries': round(float(df['food_groceries'].mean()), 2),
        'entertainment_shopping': round(float(df['entertainment_shopping'].mean()), 2),
        'other': round(float(df['other'].mean()), 2)
    }

    # Estimate next month's savings based on the last month's income minus predicted expenses
    last_month_income = float(df['income'].iloc[-1])
    predicted_savings = last_month_income - predicted_total_expense

    # Generate next month name string (e.g. Month N+1)
    # We can guess the next month name or just label it "Next Month"
    next_month_name = "Forecast"

    # Format chart data for frontend representation (both income and expenses)
    chart_data = []
    for _, row in df.iterrows():
        chart_data.append({
            'month_index': int(row['month_index']),
            'month_name': str(row['month_name']),
            'total_expenses': round(float(row['total_expenses']), 2),
            'income': round(float(row['income']), 2),
            'is_prediction': False
        })

    # Add the predicted data point to the end of the history array
    chart_data.append({
        'month_index': next_month_index,
        'month_name': next_month_name,
        'total_expenses': round(predicted_total_expense, 2),
        'income': round(last_month_income, 2), # Show income guideline
        'is_prediction': True
    })

    return {
        'predicted_total_expense': round(predicted_total_expense, 2),
        'predicted_savings': round(predicted_savings, 2),
        'avg_monthly_expense': round(avg_monthly_expense, 2),
        'category_averages': category_averages,
        'chart_data': chart_data
    }
